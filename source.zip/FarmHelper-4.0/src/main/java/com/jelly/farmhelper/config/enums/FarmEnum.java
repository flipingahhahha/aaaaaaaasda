package com.jelly.farmhelper.config.enums;

public enum FarmEnum {
    LAYERED,
    VERTICAL
}
