package com.jelly.farmhelper.config.enums;

public enum CropEnum {
        CARROT,
        NETHERWART,
        POTATO,
        WHEAT,
        SUGARCANE
}
